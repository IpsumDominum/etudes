g++ -c main.cpp&&\
g++ -c Rational.cpp&&\
g++ -c Integer.cpp&&\
g++ -o main main.o Rational.o Integer.o&&\
./main

