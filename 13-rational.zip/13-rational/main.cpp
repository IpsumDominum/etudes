#include "Integer.h"
#include "Rational.h"
#include <iostream>
using namespace cosc326;
int main(){
    Rational rat1 = Rational(Integer("1230920392039"),Integer("520392039209"));
    Rational rat2 = Rational(Integer("4023920392039"),Integer("723092039203"));
    rat1 /=rat2;
    std::cout<<rat1<<"\n";
    Integer a = Integer("100000000000000");
    Integer b = Integer("100000000000000");
    std::cout<<(a/b)<<"\n";

}
